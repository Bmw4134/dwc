// Vercel-ready API endpoint for dashboard SSR
module.exports = (req, res) => res.json({status: 'OK'});