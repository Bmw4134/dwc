def log_action(msg):
    print(f"[LOG]: {msg}")
