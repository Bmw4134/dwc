def sync_to_dashboard():
    print("Syncing agent data to dashboard")
