def deploy_honeypot():
    # Simulated deterrent
    print("⚠️ Honeypot activated. Malicious vector logged.")
