// AI Dashboard Design System - Interactive Demo (Fixed Version)
class DashboardDemo {
    constructor() {
        this.currentPlatform = null;
        this.charts = {};
        this.animationFrame = null;
        this.isChartReady = false;
        this.metrics = {
            traxovo: {
                totalRoutes: 1247,
                optimizationSavings: "23.5%",
                averageDelay: "4.2 min",
                efficiencyScore: 87
            },
            dwc: {
                activeWorkloads: 156,
                systemHealth: "98.7%",
                resourceUtilization: "74%",
                automationRate: "89%"
            },
            jdd: {
                employmentRate: "96.3%",
                jobGrowth: "+2.4%",
                sectorLeader: "Technology",
                economicIndex: 142
            },
            cryptonexus: {
                portfolioValue: "$2.4M",
                dayChange: "+5.7%",
                activePositions: 12,
                riskScore: "Moderate"
            }
        };
        
        this.platformColors = {
            traxovo: '#3B82F6',
            dwc: '#10B981',
            jdd: '#F59E0B',
            cryptonexus: '#8B5CF6'
        };

        this.init();
    }

    init() {
        // Wait for DOM to be fully loaded
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', () => this.setupAll());
        } else {
            this.setupAll();
        }
    }

    setupAll() {
        try {
            this.setupNavigation();
            this.setupPlatformCards();
            this.setupComponentInteractions();
            this.setupScrollAnimations();
            this.startMetricAnimations();
            console.log('Dashboard Demo initialized successfully');
        } catch (error) {
            console.error('Error initializing dashboard:', error);
        }
    }

    setupNavigation() {
        const navLinks = document.querySelectorAll('.nav-link');
        
        navLinks.forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                const target = link.getAttribute('href').substring(1);
                this.navigateToSection(target);
                
                // Update active state with smooth transition
                navLinks.forEach(l => l.classList.remove('active'));
                link.classList.add('active');
            });
        });
    }

    navigateToSection(sectionId) {
        const section = document.getElementById(sectionId);
        if (section) {
            section.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    }

    setupPlatformCards() {
        const platformCards = document.querySelectorAll('.platform-card');
        
        platformCards.forEach(card => {
            // Throttle hover effects to prevent flickering
            let hoverTimeout;
            
            card.addEventListener('mouseenter', () => {
                clearTimeout(hoverTimeout);
                hoverTimeout = setTimeout(() => {
                    this.animatePlatformCard(card, true);
                }, 50);
            });
            
            card.addEventListener('mouseleave', () => {
                clearTimeout(hoverTimeout);
                hoverTimeout = setTimeout(() => {
                    this.animatePlatformCard(card, false);
                }, 50);
            });
        });
    }

    animatePlatformCard(card, isHover) {
        const icon = card.querySelector('.platform-icon');
        const metrics = card.querySelectorAll('.metric-number');
        
        // Use requestAnimationFrame for smooth animations
        requestAnimationFrame(() => {
            if (isHover) {
                icon.style.transform = 'scale(1.1) rotate(5deg)';
                icon.style.transition = 'transform 0.3s cubic-bezier(0.23, 1, 0.32, 1)';
                
                metrics.forEach((metric, index) => {
                    setTimeout(() => {
                        metric.style.transform = 'scale(1.1)';
                        metric.style.color = 'var(--color-primary)';
                        metric.style.transition = 'all 0.2s ease-out';
                    }, index * 50);
                });
            } else {
                icon.style.transform = 'scale(1) rotate(0deg)';
                metrics.forEach(metric => {
                    metric.style.transform = 'scale(1)';
                    metric.style.color = 'var(--color-text)';
                });
            }
        });
    }

    setupComponentInteractions() {
        // Smart card interactions with debouncing
        const smartCards = document.querySelectorAll('.smart-card');
        smartCards.forEach(card => {
            let clickTimeout;
            card.addEventListener('click', () => {
                clearTimeout(clickTimeout);
                clickTimeout = setTimeout(() => {
                    this.animateCardClick(card);
                }, 100);
            });
        });

        // Button interactions
        const buttons = document.querySelectorAll('.btn');
        buttons.forEach(button => {
            button.addEventListener('click', (e) => {
                this.animateButtonClick(button);
            });
        });
    }

    animateCardClick(card) {
        // Use CSS transforms for better performance
        card.style.transform = 'scale(0.95)';
        card.style.transition = 'transform 0.15s cubic-bezier(0.23, 1, 0.32, 1)';
        
        setTimeout(() => {
            card.style.transform = 'scale(1)';
        }, 150);

        // Update metric with animation
        const metricValue = card.querySelector('.metric-value');
        if (metricValue) {
            const currentValue = parseFloat(metricValue.textContent);
            if (!isNaN(currentValue)) {
                const newValue = currentValue + (Math.random() * 10 - 5);
                this.animateNumber(metricValue, currentValue, Math.max(0, newValue));
            }
        }
    }

    animateButtonClick(button) {
        button.style.transform = 'scale(0.95)';
        button.style.transition = 'transform 0.1s ease-out';
        
        setTimeout(() => {
            button.style.transform = 'scale(1)';
        }, 100);

        // Add ripple effect
        this.createRippleEffect(button);
    }

    createRippleEffect(button) {
        const ripple = document.createElement('span');
        const rect = button.getBoundingClientRect();
        const size = Math.max(rect.width, rect.height);
        
        ripple.style.cssText = `
            position: absolute;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.3);
            transform: scale(0);
            animation: ripple 0.6s linear;
            left: 50%;
            top: 50%;
            width: ${size}px;
            height: ${size}px;
            margin-left: -${size/2}px;
            margin-top: -${size/2}px;
            pointer-events: none;
        `;

        if (button.style.position !== 'relative') {
            button.style.position = 'relative';
        }
        button.style.overflow = 'hidden';
        button.appendChild(ripple);

        setTimeout(() => {
            if (ripple.parentNode) {
                ripple.remove();
            }
        }, 600);
    }

    setupScrollAnimations() {
        const observerOptions = {
            threshold: 0.1,
            rootMargin: '0px 0px -50px 0px'
        };

        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('fade-in');
                }
            });
        }, observerOptions);

        // Observe all animatable elements
        document.querySelectorAll('.platform-card, .philosophy-card, .component-demo, .system-card').forEach(el => {
            observer.observe(el);
        });
    }

    startMetricAnimations() {
        // Animate metrics periodically with better timing
        setInterval(() => {
            const metricCards = document.querySelectorAll('.metric-card .metric-value');
            metricCards.forEach(metric => {
                if (Math.random() > 0.8) { // 20% chance to update
                    this.updateMetricWithAnimation(metric);
                }
            });
        }, 4000); // Increased interval to reduce frequency
    }

    updateMetricWithAnimation(element) {
        element.style.transform = 'scale(1.1)';
        element.style.color = 'var(--color-primary)';
        element.style.transition = 'all 0.3s ease-out';
        
        setTimeout(() => {
            element.style.transform = 'scale(1)';
            element.style.color = 'var(--color-text)';
        }, 300);
    }

    showPlatform(platformId) {
        this.currentPlatform = platformId;
        const demoSection = document.getElementById('platform-demo');
        const demoTitle = document.getElementById('demo-title');
        
        if (!demoSection || !demoTitle) {
            console.error('Demo section elements not found');
            return;
        }
        
        // Update title
        const platformNames = {
            traxovo: 'TRAXOVO - Travel Intelligence Dashboard',
            dwc: 'DWC - Dynamic Workload Console',
            jdd: 'JDD - Jobs Diagnostic Dashboard',
            cryptonexus: 'CryptoNexusTrade - Trading Intelligence'
        };
        
        demoTitle.textContent = platformNames[platformId] || 'Unknown Platform';
        
        // Show demo section
        demoSection.classList.remove('hidden');
        demoSection.scrollIntoView({ behavior: 'smooth' });
        
        // Update metrics
        this.updatePlatformMetrics(platformId);
        
        // Create chart with proper timing
        setTimeout(() => {
            this.createPlatformChart(platformId);
        }, 800); // Increased delay to ensure DOM is ready
        
        // Start real-time updates
        setTimeout(() => {
            this.startRealTimeUpdates(platformId);
        }, 1500);
    }

    hidePlatform() {
        const demoSection = document.getElementById('platform-demo');
        if (!demoSection) return;
        
        demoSection.classList.add('hidden');
        
        // Destroy existing chart
        if (this.charts[this.currentPlatform]) {
            try {
                this.charts[this.currentPlatform].destroy();
                delete this.charts[this.currentPlatform];
            } catch (error) {
                console.error('Error destroying chart:', error);
            }
        }
        
        // Cancel animation frame
        if (this.animationFrame) {
            cancelAnimationFrame(this.animationFrame);
            this.animationFrame = null;
        }
        
        this.currentPlatform = null;
        
        // Scroll back to platforms
        const platformsSection = document.getElementById('platforms');
        if (platformsSection) {
            platformsSection.scrollIntoView({ behavior: 'smooth' });
        }
    }

    updatePlatformMetrics(platformId) {
        const metrics = this.metrics[platformId];
        if (!metrics) return;
        
        const metricElements = document.querySelectorAll('#platform-demo .metric-value');
        const labelElements = document.querySelectorAll('#platform-demo .metric-label');
        
        if (metricElements.length >= 2 && labelElements.length >= 2) {
            const keys = Object.keys(metrics);
            
            // Animate the metric updates
            setTimeout(() => {
                if (metricElements[0]) {
                    metricElements[0].textContent = metrics[keys[0]] || 'N/A';
                    labelElements[0].textContent = this.formatLabel(keys[0]);
                }
            }, 200);
            
            setTimeout(() => {
                if (metricElements[1]) {
                    metricElements[1].textContent = metrics[keys[1]] || 'N/A';
                    labelElements[1].textContent = this.formatLabel(keys[1]);
                }
            }, 400);
        }
    }

    formatLabel(key) {
        return key.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase());
    }

    createPlatformChart(platformId) {
        const canvas = document.getElementById('platform-chart');
        if (!canvas) {
            console.error('Chart canvas not found');
            return;
        }
        
        // Wait for Chart.js to be available
        if (typeof Chart === 'undefined') {
            console.error('Chart.js not loaded');
            setTimeout(() => this.createPlatformChart(platformId), 500);
            return;
        }
        
        const ctx = canvas.getContext('2d');
        if (!ctx) {
            console.error('Could not get canvas context');
            return;
        }
        
        // Destroy existing chart
        if (this.charts[platformId]) {
            try {
                this.charts[platformId].destroy();
            } catch (error) {
                console.error('Error destroying existing chart:', error);
            }
        }
        
        const chartData = this.generateChartData(platformId);
        const color = this.platformColors[platformId] || '#3B82F6';
        
        try {
            this.charts[platformId] = new Chart(ctx, {
                type: 'line',
                data: {
                    labels: chartData.labels,
                    datasets: [{
                        label: 'Performance',
                        data: chartData.data,
                        borderColor: color,
                        backgroundColor: `${color}20`,
                        borderWidth: 3,
                        fill: true,
                        tension: 0.4,
                        pointBackgroundColor: color,
                        pointBorderColor: '#ffffff',
                        pointBorderWidth: 2,
                        pointRadius: 6,
                        pointHoverRadius: 8
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            display: false
                        }
                    },
                    scales: {
                        x: {
                            grid: {
                                color: 'rgba(0, 0, 0, 0.1)'
                            },
                            ticks: {
                                font: {
                                    size: 12
                                }
                            }
                        },
                        y: {
                            grid: {
                                color: 'rgba(0, 0, 0, 0.1)'
                            },
                            ticks: {
                                font: {
                                    size: 12
                                }
                            },
                            beginAtZero: true
                        }
                    },
                    elements: {
                        point: {
                            hoverBorderWidth: 3
                        }
                    },
                    animation: {
                        duration: 1500,
                        easing: 'easeInOutQuart'
                    }
                }
            });
            
            this.isChartReady = true;
            console.log(`Chart created successfully for ${platformId}`);
            
        } catch (error) {
            console.error('Error creating chart:', error);
        }
    }

    generateChartData(platformId) {
        const baseData = {
            traxovo: {
                labels: ['6h', '5h', '4h', '3h', '2h', '1h', 'Now'],
                base: [85, 87, 89, 86, 90, 88, 92]
            },
            dwc: {
                labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
                base: [78, 82, 85, 88, 86, 89, 91]
            },
            jdd: {
                labels: ['Q1', 'Q2', 'Q3', 'Q4', 'Q1', 'Q2', 'Now'],
                base: [72, 75, 78, 81, 83, 86, 88]
            },
            cryptonexus: {
                labels: ['W1', 'W2', 'W3', 'W4', 'W5', 'W6', 'Now'],
                base: [95, 98, 102, 99, 105, 108, 112]
            }
        };

        const platform = baseData[platformId] || baseData.traxovo;
        return {
            labels: platform.labels,
            data: platform.base.map(val => Math.round(val + (Math.random() * 6 - 3)))
        };
    }

    startRealTimeUpdates(platformId) {
        if (this.animationFrame) {
            cancelAnimationFrame(this.animationFrame);
        }

        let updateCount = 0;
        const maxUpdates = 10; // Limit updates to prevent infinite loops

        const updateChart = () => {
            if (!this.charts[platformId] || 
                this.currentPlatform !== platformId || 
                updateCount >= maxUpdates ||
                !this.isChartReady) {
                return;
            }

            try {
                const chart = this.charts[platformId];
                const data = chart.data.datasets[0].data;
                
                // Add new data point
                const lastValue = data[data.length - 1] || 50;
                const newValue = Math.round(lastValue + (Math.random() * 4 - 2));
                data.push(Math.max(0, Math.min(100, newValue)));
                
                // Remove old data point if too many
                if (data.length > 10) {
                    data.shift();
                    chart.data.labels.shift();
                    chart.data.labels.push('Now');
                }
                
                chart.update('none');
                updateCount++;
                
                // Schedule next update
                setTimeout(() => {
                    this.animationFrame = requestAnimationFrame(updateChart);
                }, 3000);
                
            } catch (error) {
                console.error('Error updating chart:', error);
            }
        };

        // Start updates after initial chart creation
        setTimeout(() => {
            if (this.isChartReady) {
                this.animationFrame = requestAnimationFrame(updateChart);
            }
        }, 2000);
    }

    animateNumber(element, from, to) {
        if (!element || isNaN(from) || isNaN(to)) return;
        
        const duration = 800;
        const start = performance.now();
        const isPercentage = element.textContent.includes('%');
        const isDollar = element.textContent.includes('$');
        
        const animate = (currentTime) => {
            const elapsed = currentTime - start;
            const progress = Math.min(elapsed / duration, 1);
            
            const current = from + (to - from) * this.easeOutQuart(progress);
            let value = Math.round(current * 10) / 10;
            
            try {
                if (isPercentage) {
                    element.textContent = `${value.toFixed(1)}%`;
                } else if (isDollar) {
                    element.textContent = `$${value.toFixed(1)}M`;
                } else {
                    element.textContent = Math.round(value).toString();
                }
            } catch (error) {
                console.error('Error updating element text:', error);
            }
            
            if (progress < 1) {
                requestAnimationFrame(animate);
            }
        };
        
        requestAnimationFrame(animate);
    }

    easeOutQuart(t) {
        return 1 - Math.pow(1 - t, 4);
    }
}

// Global functions for HTML onclick handlers
function showPlatform(platformId) {
    if (window.dashboardDemo) {
        window.dashboardDemo.showPlatform(platformId);
    }
}

function hidePlatform() {
    if (window.dashboardDemo) {
        window.dashboardDemo.hidePlatform();
    }
}

function navigateToSection(sectionId) {
    if (window.dashboardDemo) {
        window.dashboardDemo.navigateToSection(sectionId);
    }
}

// Enhanced CSS for ripple animation
const rippleStyles = `
@keyframes ripple {
    to {
        transform: scale(4);
        opacity: 0;
    }
}

/* Fix for potential flickering issues */
.philosophy-card, .platform-card, .smart-card {
    will-change: transform;
    backface-visibility: hidden;
    -webkit-backface-visibility: hidden;
}

/* Smooth transitions */
.btn, .nav-link {
    will-change: transform;
}
`;

// Wait for DOM before adding styles
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', addStyles);
} else {
    addStyles();
}

function addStyles() {
    const styleSheet = document.createElement('style');
    styleSheet.textContent = rippleStyles;
    document.head.appendChild(styleSheet);
}

// Initialize everything when ready
function initializeApp() {
    try {
        // Initialize main dashboard demo
        window.dashboardDemo = new DashboardDemo();
        
        console.log('AI Dashboard Design System Demo Loaded Successfully');
        console.log('Performance:', {
            loadTime: Math.round(performance.now()),
            userAgent: navigator.userAgent.substring(0, 50) + '...',
            viewport: `${window.innerWidth}x${window.innerHeight}`,
            chartJsAvailable: typeof Chart !== 'undefined'
        });
        
    } catch (error) {
        console.error('Error initializing app:', error);
    }
}

// Initialize when DOM and Chart.js are ready
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
        // Wait a bit more for Chart.js to load
        setTimeout(initializeApp, 100);
    });
} else {
    setTimeout(initializeApp, 100);
}

// Handle window resize for responsive charts
window.addEventListener('resize', debounce(() => {
    if (window.dashboardDemo?.charts) {
        Object.values(window.dashboardDemo.charts).forEach(chart => {
            if (chart && typeof chart.resize === 'function') {
                try {
                    chart.resize();
                } catch (error) {
                    console.error('Error resizing chart:', error);
                }
            }
        });
    }
}, 250));

// Debounce utility function
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}