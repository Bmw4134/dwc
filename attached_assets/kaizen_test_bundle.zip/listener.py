
# listener.py
from flask import Flask, request
from auditor import TradeAuditor

app = Flask(__name__)
auditor = TradeAuditor()

@app.route("/record_trade", methods=["POST"])
def record():
    data = request.json
    auditor.record_trade(**data)
    return {"status": "recorded"}, 200

@app.route("/summary", methods=["GET"])
def summary():
    return auditor.summary(), 200

if __name__ == "__main__":
    app.run(port=5000)
