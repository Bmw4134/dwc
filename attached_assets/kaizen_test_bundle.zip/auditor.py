
# auditor.py
import json
from datetime import datetime

class TradeAuditor:
    def __init__(self, log_path='trade_log.json'):
        self.log_path = log_path
        self.load_log()

    def load_log(self):
        try:
            with open(self.log_path, 'r') as f:
                self.trades = json.load(f)
        except FileNotFoundError:
            self.trades = []

    def record_trade(self, pnl, strategy, win):
        self.trades.append({
            "timestamp": datetime.now().isoformat(),
            "pnl": pnl,
            "strategy": strategy,
            "win": win
        })
        self._save()

    def _save(self):
        with open(self.log_path, 'w') as f:
            json.dump(self.trades, f, indent=2)

    def summary(self):
        total_trades = len(self.trades)
        wins = sum(1 for t in self.trades if t["win"])
        pnl = sum(t["pnl"] for t in self.trades)
        return {
            "total_trades": total_trades,
            "win_rate": wins / total_trades if total_trades else 0,
            "total_pnl": pnl
        }
