#!/bin/bash
python3 kaizen_ultra_agent.py