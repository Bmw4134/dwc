import pandas as pd
import plotly.graph_objects as go
import numpy as np

# Load the data
df = pd.read_csv("data_storytelling_framework.csv")

# Extract the stages and values for each philosophy
stages = df['Stage'].tolist()
linear_clarity = df['Linear_Clarity'].tolist()
apple_emotion = df['Apple_Emotion'].tolist()
palantir_intelligence = df['Palantir_Intelligence'].tolist()

# Abbreviate stage names to fit 15 character limit
stage_abbrev = []
for stage in stages:
    if stage == "Context Setting":
        stage_abbrev.append("Context Set")
    elif stage == "Data Exploration":
        stage_abbrev.append("Data Explore")
    elif stage == "Insight Discovery":
        stage_abbrev.append("Insight Disc")
    elif stage == "Action Planning":
        stage_abbrev.append("Action Plan")
    elif stage == "Outcome Tracking":
        stage_abbrev.append("Outcome Track")
    else:
        stage_abbrev.append(stage[:15])

# Create the radar chart
fig = go.Figure()

# Add Linear Clarity trace (blue)
fig.add_trace(go.Scatterpolar(
    r=linear_clarity,
    theta=stage_abbrev,
    fill='toself',
    name='Linear Clarity',
    line_color='#1FB8CD',
    fillcolor='rgba(31, 184, 205, 0.2)',
    cliponaxis=False,
    line_width=2
))

# Add Apple Emotion trace (red)
fig.add_trace(go.Scatterpolar(
    r=apple_emotion,
    theta=stage_abbrev,
    fill='toself',
    name='Apple Emotion',
    line_color='#B4413C',
    fillcolor='rgba(180, 65, 60, 0.2)',
    cliponaxis=False,
    line_width=2
))

# Add Palantir Intelligence trace (green)
fig.add_trace(go.Scatterpolar(
    r=palantir_intelligence,
    theta=stage_abbrev,
    fill='toself',
    name='Palantir Intel',
    line_color='#ECEBD5',
    fillcolor='rgba(236, 235, 213, 0.2)',
    cliponaxis=False,
    line_width=2
))

# Update layout
fig.update_layout(
    polar=dict(
        radialaxis=dict(
            visible=True,
            range=[0, 100],
            tickmode='linear',
            tick0=0,
            dtick=20
        )
    ),
    title="Design Philosophy Comparison",
    legend=dict(orientation='h', yanchor='bottom', y=1.05, xanchor='center', x=0.5)
)

# Save the chart
fig.write_image("radar_chart.png")
print("Radar chart saved successfully!")