import pandas as pd
import plotly.express as px
import plotly.graph_objects as go

# Load the data
df = pd.read_csv("ai_dashboard_design_system_components.csv")

# Create hierarchy for treemap
# Add a count column for sizing (each component gets value 1)
df['count'] = 1

# Create proper hierarchy labels
df['hierarchy'] = df['Layer'] + ' / ' + df['Category'] + ' / ' + df['Component']

# Define color mapping for layers based on the requested color scheme
layer_colors = {
    'Foundation Layer': '#5D878F',  # Cyan (blue-gray)
    'Component Layer': '#ECEBD5',   # Light green
    'Pattern Layer': '#FFC185',     # Light orange
    'Platform Layer': '#1FB8CD'     # Strong cyan (purple-like blue)
}

# Add color column based on layer
df['color'] = df['Layer'].map(layer_colors)

# Create treemap
fig = go.Figure(go.Treemap(
    labels=df['Component'],
    parents=df['Category'],
    values=df['count'],
    textinfo="label",
    hovertemplate='%{label}<br>Layer: %{parent}<extra></extra>',
    maxdepth=3,
    branchvalues="total"
))

# Add category level
categories = df.groupby(['Layer', 'Category']).size().reset_index(name='count')
categories['parent'] = categories['Layer']
categories['label'] = categories['Category']
categories['color'] = categories['Layer'].map(layer_colors)

# Add layer level
layers = df.groupby('Layer').size().reset_index(name='count')
layers['parent'] = ""
layers['label'] = layers['Layer'].str.replace(' Layer', '')
layers['color'] = layers['Layer'].map(layer_colors)

# Combine all levels for proper hierarchy
all_data = []

# Add layers (top level)
for _, row in layers.iterrows():
    all_data.append({
        'ids': row['Layer'],
        'labels': row['label'],
        'parents': "",
        'values': row['count']
    })

# Add categories (second level)
for _, row in categories.iterrows():
    all_data.append({
        'ids': row['Layer'] + '/' + row['Category'],
        'labels': row['Category'][:15],  # Truncate to 15 chars
        'parents': row['Layer'],
        'values': row['count']
    })

# Add components (third level)
for _, row in df.iterrows():
    all_data.append({
        'ids': row['Layer'] + '/' + row['Category'] + '/' + row['Component'],
        'labels': row['Component'][:15],  # Truncate to 15 chars
        'parents': row['Layer'] + '/' + row['Category'],
        'values': row['count']
    })

# Convert to DataFrame
treemap_df = pd.DataFrame(all_data)

# Create the treemap
fig = go.Figure(go.Treemap(
    ids=treemap_df['ids'],
    labels=treemap_df['labels'],
    parents=treemap_df['parents'],
    values=treemap_df['values'],
    branchvalues="total",
    maxdepth=3,
    textinfo="label",
    textfont_size=12,
    hovertemplate='%{label}<extra></extra>'
))

# Update layout
fig.update_layout(
    title="Design System Architecture",
    font=dict(size=14)
)

# Save the chart
fig.write_image("design_system_treemap.png")
print("Chart saved successfully!")