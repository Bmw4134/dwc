import pandas as pd
import json

# Create a comprehensive design system component hierarchy
design_system_data = {
    "Foundation Layer": {
        "Design Tokens": ["Colors", "Typography", "Spacing", "Elevation", "Motion"],
        "Cognitive Principles": ["Progressive Disclosure", "Chunking", "Recognition over Recall", "Consistency", "Error Prevention"],
        "Brand Elements": ["Visual Identity", "Voice & Tone", "Iconography", "Imagery", "Logo System"]
    },
    "Component Layer": {
        "Data Visualization": ["Charts & Graphs", "KPI Cards", "Real-time Indicators", "Progress Bars", "Heatmaps"],
        "Navigation": ["Sidebar", "Breadcrumbs", "Tabs", "Pagination", "Command Palette"],
        "Input Controls": ["Forms", "Filters", "Search", "Date Pickers", "Toggles"],
        "Feedback": ["Notifications", "Loading States", "Error Messages", "Success States", "Tooltips"]
    },
    "Pattern Layer": {
        "Dashboard Layouts": ["Grid System", "Panel Organization", "Responsive Breakpoints", "Information Hierarchy"],
        "Data Storytelling": ["Narrative Flow", "Contextual Insights", "Comparative Analysis", "Trend Visualization"],
        "Interaction Patterns": ["Drill-down", "Hover States", "Animations", "Gestures", "Keyboard Navigation"]
    },
    "Platform Layer": {
        "TRAXOVO": ["Travel Analytics", "Route Optimization", "Predictive Modeling", "Real-time Tracking"],
        "DWC": ["Workload Management", "Resource Allocation", "Performance Monitoring", "Automation Dashboard"],
        "JDD": ["Job Diagnostics", "Demand Analysis", "Economic Indicators", "Sector Performance"],
        "CryptoNexusTrade": ["Portfolio Management", "Market Analysis", "Trading Signals", "Risk Assessment"]
    }
}

# Convert to a flat structure for CSV export
design_system_flat = []
for layer, categories in design_system_data.items():
    for category, components in categories.items():
        for component in components:
            design_system_flat.append({
                "Layer": layer,
                "Category": category,
                "Component": component,
                "Priority": "High" if layer in ["Foundation Layer", "Component Layer"] else "Medium",
                "Implementation_Complexity": "Low" if layer == "Foundation Layer" else "Medium" if layer == "Component Layer" else "High"
            })

df_design_system = pd.DataFrame(design_system_flat)
df_design_system.to_csv("ai_dashboard_design_system_components.csv", index=False)

print("Design System Component Structure:")
print(df_design_system.head(10))
print(f"\nTotal components: {len(df_design_system)}")
print(f"Distribution by layer:")
print(df_design_system['Layer'].value_counts())