import pandas as pd
import plotly.express as px
import plotly.graph_objects as go

# Load the data
df = pd.read_csv("ai_dashboard_design_system_components.csv")

# Group data by Layer and Implementation_Complexity to get counts
grouped = df.groupby(['Layer', 'Implementation_Complexity']).size().reset_index(name='Count')

# Create abbreviated layer names to fit 15 character limit
layer_abbreviations = {
    'Foundation Layer': 'Foundation',
    'Component Layer': 'Components',
    'Pattern Layer': 'Patterns', 
    'Platform Layer': 'Platform'
}

grouped['Layer_Short'] = grouped['Layer'].map(layer_abbreviations)
print("Grouped data with short names:")
print(grouped)

# Define color mapping: Low=blue, Medium=green, High=red
color_map = {
    'Low': '#1FB8CD',     # Blue
    'Medium': '#ECEBD5',  # Light green
    'High': '#B4413C'     # Red
}

# Create stacked horizontal bar chart
fig = px.bar(grouped, 
             x='Count', 
             y='Layer_Short', 
             color='Implementation_Complexity',
             orientation='h',
             title='AI Design System: Components by Layer',
             color_discrete_map=color_map,
             category_orders={'Implementation_Complexity': ['Low', 'Medium', 'High']})

# Update layout following the guidelines
fig.update_layout(
    legend=dict(orientation='h', yanchor='bottom', y=1.05, xanchor='center', x=0.5),
    xaxis_title='Num Components',
    yaxis_title='Layer',
    barmode='stack'  # Ensure bars are stacked
)

# Apply cliponaxis=False
fig.update_traces(cliponaxis=False)

# Save the chart
fig.write_image("component_distribution_chart.png")
fig.show()