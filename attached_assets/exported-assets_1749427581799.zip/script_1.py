# Create a data storytelling framework for AI dashboards
storytelling_framework = {
    "Stage": ["Context Setting", "Data Exploration", "Insight Discovery", "Action Planning", "Outcome Tracking"],
    "Linear_Clarity": [95, 85, 75, 90, 80],
    "Apple_Emotion": [80, 70, 90, 85, 75], 
    "Palantir_Intelligence": [70, 95, 95, 80, 90],
    "User_Engagement": [85, 80, 95, 90, 85],
    "Technical_Accuracy": [75, 95, 90, 85, 95]
}

df_storytelling = pd.DataFrame(storytelling_framework)
df_storytelling.to_csv("data_storytelling_framework.csv", index=False)

# Create cognitive load analysis for different dashboard types
cognitive_load_data = {
    "Dashboard_Type": ["Simple KPI", "Multi-metric", "Real-time Analytics", "Complex Financial", "AI-driven Insights"],
    "Information_Elements": [5, 12, 25, 40, 30],
    "Cognitive_Load_Score": [2, 4, 7, 9, 6],
    "User_Success_Rate": [95, 88, 75, 60, 78],
    "Time_to_Insight": [10, 30, 120, 300, 180]  # seconds
}

df_cognitive = pd.DataFrame(cognitive_load_data)
df_cognitive.to_csv("cognitive_load_analysis.csv", index=False)

print("Data Storytelling Framework:")
print(df_storytelling)
print("\nCognitive Load Analysis:")
print(df_cognitive)