import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from sklearn.linear_model import LinearRegression
import numpy as np

# Load the data
df = pd.read_csv("cognitive_load_analysis.csv")

# Abbreviate Dashboard_Type for labels (keeping under 15 chars)
df['Type_Short'] = df['Dashboard_Type'].str.replace('Dashboard', 'DB').str.replace('_', ' ')

# Create the scatter plot with text labels
fig = px.scatter(df, 
                 x='Cognitive_Load_Score', 
                 y='User_Success_Rate',
                 size='Time_to_Insight',
                 color='Information_Elements',
                 text='Type_Short',
                 hover_name='Dashboard_Type',
                 color_continuous_scale='Blues',
                 title='Cognitive Load vs User Success',
                 size_max=20)

# Update traces to use cliponaxis=False and position text
fig.update_traces(cliponaxis=False, 
                 textposition='top center',
                 textfont_size=10)

# Update axis labels (keeping under 15 characters)
fig.update_xaxes(title='Cognitive Load')
fig.update_yaxes(title='Success Rate %')

# Add trend line
x_vals = df['Cognitive_Load_Score'].values.reshape(-1, 1)
y_vals = df['User_Success_Rate'].values
model = LinearRegression().fit(x_vals, y_vals)
x_trend = np.linspace(df['Cognitive_Load_Score'].min(), df['Cognitive_Load_Score'].max(), 100)
y_trend = model.predict(x_trend.reshape(-1, 1))

fig.add_trace(go.Scatter(x=x_trend, y=y_trend, 
                        mode='lines', 
                        name='Trend',
                        line=dict(color='red', width=2),
                        cliponaxis=False,
                        showlegend=True))

# Update hover template for scatter points only
fig.update_traces(hovertemplate='<b>%{hovertext}</b><br>' +
                               'Cognitive Load: %{x}<br>' +
                               'Success Rate: %{y}%<br>' +
                               'Time to Insight: %{marker.size}<br>' +
                               '<extra></extra>',
                 selector=dict(mode='markers+text'))

# Update layout for legend positioning
fig.update_layout(legend=dict(orientation='h', yanchor='bottom', y=1.05, xanchor='center', x=0.5))

# Save the chart
fig.write_image("cognitive_load_scatter.png")