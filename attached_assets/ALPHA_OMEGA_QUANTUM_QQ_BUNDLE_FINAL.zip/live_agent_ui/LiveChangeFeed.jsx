// React component for LiveChangeFeed UI integration
