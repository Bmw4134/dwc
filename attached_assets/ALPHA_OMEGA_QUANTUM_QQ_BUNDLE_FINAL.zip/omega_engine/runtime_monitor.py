# Tracks module activation states and pushes logs to frontend
