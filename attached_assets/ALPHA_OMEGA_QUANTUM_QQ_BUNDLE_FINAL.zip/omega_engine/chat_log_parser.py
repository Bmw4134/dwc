# Parses entire Replit agent history for unfulfilled tasks
