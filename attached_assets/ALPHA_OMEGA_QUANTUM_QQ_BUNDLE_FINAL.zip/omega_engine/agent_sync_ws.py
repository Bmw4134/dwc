# WebSocket backend feed for real-time UI updates
