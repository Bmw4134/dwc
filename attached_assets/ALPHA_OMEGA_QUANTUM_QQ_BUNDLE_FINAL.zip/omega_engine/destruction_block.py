# Prevents any destructive action without confirmation
