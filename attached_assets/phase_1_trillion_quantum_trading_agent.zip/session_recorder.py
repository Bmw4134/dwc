# Tracks user interactions to model session flow for future auto-trades
