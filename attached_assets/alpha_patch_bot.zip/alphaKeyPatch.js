require('dotenv').config();

const alphaKey = process.env.ALPHA_VANTAGE_API_KEY || "YOUR_FALLBACK_KEY_HERE";

if (!alphaKey || alphaKey === "YOUR_FALLBACK_KEY_HERE") {
    throw new Error("❌ Missing Alpha Vantage API Key. Please set it in Replit secrets or .env");
}

console.log("✅ Alpha Key Loaded:", alphaKey.substring(0, 6) + "...");
