// Attaches behavioral interface modeling tags to all interactive elements
document.querySelectorAll("[data-bim]").forEach(el => {
    el.addEventListener("click", () => {
        console.log(`BIM Triggered: ${el.getAttribute("data-bim")}`);
        // Send event to backend or analytics if needed
    });
});
