# OAuth2 and SSO Handler
print('SSO Active')