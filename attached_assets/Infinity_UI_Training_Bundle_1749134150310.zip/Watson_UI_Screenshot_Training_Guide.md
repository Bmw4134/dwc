
# 🚀 Watson UI Screenshot Training Guide

## 🎯 Purpose
Empower real-time UI/UX feedback and enhancement by uploading screenshots and training the Watson UI Style Engine.

---

## 📱 Mobile Use

1. **Take a Screenshot**
2. Open your Dashboard on Mobile.
3. Navigate to `Watson → UI Trainer → Upload UI Sample`
4. Upload your screenshot:
   - 👍 Mark as GOOD UI
   - 👎 Mark as BAD UI
5. (Optional) Add a note, e.g. "Too cluttered" or "Font feels outdated".

---

## 💻 Desktop Use

### Training via Local Path:

```bash
cp screenshot.png /watson/ui-style/input/
watson-train-ui-style --now
```

---

## 🔐 Security

- User-level screenshot encryption.
- Training models are not cross-merged unless explicitly triggered via Infinity Fusion.

---

## 🌌 Next-Level Mode (Optional)

Enable `Infinity Style Watchdog`:
```bash
watson-enable-style-watchdog --threshold=90
```

This mode flags any new screens scoring < 90/100 on your visual preferences and auto-generates improvement suggestions.

---
