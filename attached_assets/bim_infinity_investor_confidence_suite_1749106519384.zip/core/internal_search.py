import streamlit as st

def render_search():
    st.sidebar.text_input("🔍 Search across system")
