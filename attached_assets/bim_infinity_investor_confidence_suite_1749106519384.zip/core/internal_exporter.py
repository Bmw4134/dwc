import streamlit as st
import json

def render_exporter(data=None):
    st.sidebar.title("📦 Export Data")
    if data is None:
        data = {"message": "Test export"}
    st.download_button("Export JSON", data=json.dumps(data, indent=2), file_name="export.json")
