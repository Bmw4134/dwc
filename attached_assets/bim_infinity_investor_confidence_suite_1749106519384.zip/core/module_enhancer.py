def enhance_existing_modules(modules):
    return [f"{m} (augmented)" for m in modules]
