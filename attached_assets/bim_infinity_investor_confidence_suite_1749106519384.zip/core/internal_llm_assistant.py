import streamlit as st

def render_llm_chat():
    st.sidebar.title("💬 Internal LLM Assistant")
    user_prompt = st.text_area("What do you want help with?")
    if st.button("Submit to LLM"):
        st.write("Response (simulated): 🤖 You're asking about:", user_prompt)
