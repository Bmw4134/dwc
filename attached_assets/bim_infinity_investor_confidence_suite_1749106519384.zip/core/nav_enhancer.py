def enhance_nav_routes(existing_routes):
    canonical = ["home", "dashboard", "automation", "profile", "settings"]
    final_routes = list(dict.fromkeys(existing_routes + canonical))
    return final_routes
