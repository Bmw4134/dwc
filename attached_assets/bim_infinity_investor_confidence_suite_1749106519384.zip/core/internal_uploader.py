import streamlit as st

def render_uploader():
    st.sidebar.title("📤 Upload Files")
    uploaded = st.sidebar.file_uploader("Upload any relevant files:")
    if uploaded:
        st.success(f"Uploaded: {uploaded.name}")
