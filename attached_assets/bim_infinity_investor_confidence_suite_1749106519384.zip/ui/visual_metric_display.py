import streamlit as st
import pandas as pd

def render_dynamic_metric(data_source):
    st.title("📈 Real-Time Metric Display")
    df = pd.read_json(data_source)
    st.line_chart(df["value"])
    st.write("Last Updated:", df["timestamp"].iloc[-1])
