import streamlit as st

def render_mobile_navigation():
    st.markdown("## 📱 App-Style Navigation")
    tab = st.radio("Go To", ["🏠 Home", "📊 Dashboard", "🛠 Automation", "👤 Profile", "🔧 Settings"], horizontal=True)
    st.session_state["active_tab"] = tab
    return tab
