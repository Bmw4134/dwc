import streamlit as st

def apply_scrollable_layout():
    st.markdown(
        """
        <style>
        .block-container {
            padding-top: 1rem;
            padding-bottom: 1rem;
            overflow-y: auto;
            max-height: 95vh;
        }
        </style>
        """, unsafe_allow_html=True
    )
