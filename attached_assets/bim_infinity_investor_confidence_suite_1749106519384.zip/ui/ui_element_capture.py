import streamlit as st
from PIL import Image
import io

def capture_ui_element():
    st.title("📸 UI Element Capture")
    uploaded = st.file_uploader("Upload screenshot of UI element")
    if uploaded:
        img = Image.open(uploaded)
        st.image(img, caption="Captured Element")
        st.success("📌 Element ready for backend analysis (manual or agent).")
