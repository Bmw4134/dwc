def enforce_auto_enhance_only():
    return "🧠 Agent restricted: enhance/augment only. No new module creation unless explicitly approved."
