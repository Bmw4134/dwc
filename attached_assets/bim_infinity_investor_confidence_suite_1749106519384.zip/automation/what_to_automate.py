import streamlit as st

def render_automation_suggester():
    st.title("🤖 What do you want to automate today?")
    choice = st.selectbox("Choose automation type", ["File conversion", "Data analysis", "Report generation", "Other"])
    st.text_area("Describe your automation goal")
    if st.button("Launch Agent"):
        st.success("🚀 Agent launched with your intent.")
