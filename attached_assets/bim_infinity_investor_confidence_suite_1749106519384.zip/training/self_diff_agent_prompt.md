**Given**: Revit files changed 3 times this week  
**When**: Patterns of manual duct rerouting are detected  
**Then**: Auto-suggest Dynamo nodes or family updates

> Prompt:  
"Analyze model change history for repetitive manual edits. Suggest automated replacements in Dynamo for routing patterns."
