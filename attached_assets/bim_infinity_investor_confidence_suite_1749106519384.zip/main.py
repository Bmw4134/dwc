from navigation.router import BIMRouteNavigator

def run():
    BIMRouteNavigator().run()

if __name__ == "__main__":
    run()
