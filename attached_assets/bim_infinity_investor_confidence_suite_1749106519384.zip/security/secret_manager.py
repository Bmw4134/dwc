import os

def list_replit_secrets():
    return [k for k in os.environ if "SECRET" in k or "API" in k]

def check_for_duplicates(secrets):
    seen = set()
    dups = set()
    for s in secrets:
        if s in seen:
            dups.add(s)
        else:
            seen.add(s)
    return list(dups)

def deduplicate_secrets():
    secrets = list_replit_secrets()
    dups = check_for_duplicates(secrets)
    return dups  # Simulated cleanup
