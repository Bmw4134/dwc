import streamlit as st
import time

def secure_login(username, password):
    VALID_USERS = {"admin": "watson123"}
    if VALID_USERS.get(username) == password:
        st.session_state["authenticated"] = True
        st.success("✅ Login successful.")
    else:
        st.error("❌ Invalid credentials.")

def render_login():
    st.title("🔐 Secure Login Gateway")
    username = st.text_input("Username")
    password = st.text_input("Password", type="password")
    if st.button("Login"):
        secure_login(username, password)
