import streamlit as st
import json
import os

def render_replit_agent_status():
    st.title("🧠 Replit Agent Tracker")
    if os.path.exists("goal_tracker.json"):
        with open("goal_tracker.json", "r") as f:
            goals = json.load(f)
            st.markdown("### Agent Goals + Patch Status")
            for g in goals[-5:]:
                st.success(f"{g['goal_text']} → {g['status']}")
    else:
        st.warning("No goal tracker found.")
