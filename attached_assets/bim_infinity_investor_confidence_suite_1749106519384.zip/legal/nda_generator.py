import streamlit as st
from datetime import datetime

def render_nda_form():
    st.title("📝 NDA Intake and Signature Form")
    st.markdown("**This system is proprietary. Access requires NDA.**")

    name = st.text_input("Full Name")
    email = st.text_input("Email")
    org = st.text_input("Organization")
    agreed = st.checkbox("I agree to the NDA terms")

    if st.button("Submit NDA") and agreed:
        with open("nda_signatures.log", "a") as f:
            f.write(f"{datetime.utcnow().isoformat()} | {name} | {email} | {org} | AGREED\n")
        st.success("✅ NDA signed and recorded.")
