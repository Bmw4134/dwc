
import os
import getpass

def validate_pionex_credentials():
    api_key = os.getenv("PIONEX_API_KEY")
    api_secret = os.getenv("PIONEX_API_SECRET")

    if not api_key or not api_secret:
        raise Exception("Missing Pionex API credentials in environment variables.")

    print("[AUTH] Pionex credentials loaded successfully.")
    return api_key, api_secret
