
from auth_bootstrap import validate_pionex_credentials

def run_trading_bot():
    api_key, api_secret = validate_pionex_credentials()
    print(f"🚀 Trading bot initialized with key: {api_key[:4]}****")

if __name__ == "__main__":
    run_trading_bot()
