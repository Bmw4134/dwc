# Secure Auth

This module contains logic for secure auth.