# Mobile Scaler

This module contains logic for mobile scaler.