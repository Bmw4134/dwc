# Trading Strategy Core

This module contains logic for trading strategy core.