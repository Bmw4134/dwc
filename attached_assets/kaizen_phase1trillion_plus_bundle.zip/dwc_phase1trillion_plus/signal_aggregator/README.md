# Signal Aggregator

This module contains logic for signal aggregator.