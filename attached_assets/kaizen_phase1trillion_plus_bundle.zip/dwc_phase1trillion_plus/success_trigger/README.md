# Success Trigger

This module contains logic for success trigger.