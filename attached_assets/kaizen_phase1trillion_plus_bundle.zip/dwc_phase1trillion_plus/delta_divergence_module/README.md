# Delta Divergence Module

This module contains logic for delta divergence module.