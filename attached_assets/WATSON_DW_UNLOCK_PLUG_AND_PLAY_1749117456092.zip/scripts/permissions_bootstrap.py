
def unlock_restricted_modules(dashboard):
    if current_user.role in ["admin", "ops", "founder"]:
        dashboard.modules["restricted"] = "unlocked"
        dashboard.log("🟢 Restrictions lifted for trusted role.")
