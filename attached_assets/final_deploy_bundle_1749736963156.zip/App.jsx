
import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Login from './login';
import NexusTraderDashboard from './ui_components/updated_nexus_trader_dashboard';

export default function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Login />} />
        <Route path="/dashboard" element={<NexusTraderDashboard />} />
      </Routes>
    </Router>
  );
}
