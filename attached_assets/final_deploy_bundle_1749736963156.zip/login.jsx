
import React, { useState } from 'react';

export default function Login() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  function handleLogin(e) {
    e.preventDefault();
    // Placeholder for real auth logic
    alert("Logging in...");
  }

  return (
    <div className="flex items-center justify-center h-screen bg-gradient-to-br from-gray-900 to-black">
      <form onSubmit={handleLogin} className="bg-gray-800 p-6 rounded-lg shadow-xl w-80">
        <h2 className="text-green-400 text-xl font-bold mb-4">DWC Systems LLC</h2>
        <p className="text-sm text-gray-400 mb-6">QNIS/PTNI Intelligence Platform</p>
        <input
          type="text"
          placeholder="Username"
          value={username}
          onChange={(e) => setUsername(e.target.value)}
          className="w-full mb-3 px-3 py-2 bg-gray-700 text-white rounded"
        />
        <input
          type="password"
          placeholder="Password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          className="w-full mb-4 px-3 py-2 bg-gray-700 text-white rounded"
        />
        <button type="submit" className="w-full bg-green-600 hover:bg-green-700 text-white py-2 rounded">
          Access Platform
        </button>
        <p className="text-xs text-gray-500 mt-3 text-center">Need help? Contact your administrator.</p>
      </form>
    </div>
  );
}
