
import React, { useState, useEffect } from 'react';

export default function DWCConsole() {
  const [lastTrigger, setLastTrigger] = useState(null);
  const [log, setLog] = useState([]);

  function sendTrigger(trigger) {
    fetch('/api/dwc', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({trigger})
    })
    .then(res => res.json())
    .then(data => {
      setLastTrigger(trigger);
      setLog(prev => [...prev, `[${trigger}]: ${data.result}`]);
    });
  }

  return (
    <div className="bg-gray-900 text-green-400 p-4 rounded-xl">
      <h2 className="text-lg font-bold mb-2">⚙️ DWC Console</h2>
      <div className="space-x-2 mb-4">
        {["RealityMode", "EngineStart", "BalanceRefresh"].map(trigger => (
          <button key={trigger} onClick={() => sendTrigger(trigger)} className="bg-green-700 px-3 py-1 rounded">
            {trigger}
          </button>
        ))}
      </div>
      <div className="bg-black p-2 rounded h-32 overflow-y-auto text-sm">
        {log.map((entry, idx) => <div key={idx}>{entry}</div>)}
      </div>
    </div>
  );
}
