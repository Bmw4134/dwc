def fusion_chain_handler(): pass
