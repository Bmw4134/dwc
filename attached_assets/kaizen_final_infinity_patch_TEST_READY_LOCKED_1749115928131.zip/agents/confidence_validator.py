def confidence_validator(): pass
