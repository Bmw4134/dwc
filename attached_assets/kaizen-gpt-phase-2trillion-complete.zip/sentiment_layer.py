# Ingests Twitter, Reddit, RSS to adjust short-term bias
