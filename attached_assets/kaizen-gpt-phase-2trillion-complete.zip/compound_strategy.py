# On-profit compounding logic: 100 → 500 → 5000 goals
