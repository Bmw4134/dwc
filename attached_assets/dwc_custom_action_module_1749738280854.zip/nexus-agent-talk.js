
export default async function handler(req, res) {
  const { prompt } = req.body;
  const timestamp = new Date().toISOString();
  const response = `🧠 Nexus-DWC received at ${timestamp}: ${prompt}. Protocol dispatched.`;
  res.status(200).json({ response });
}
