import React from 'react';

const Settings = () => {
  return (
    <div style={{ padding: '2rem' }}>
      <h1>Settings</h1>
      <p>This is the settings page. Modify user preferences or app config here.</p>
    </div>
  );
};

export default Settings;
