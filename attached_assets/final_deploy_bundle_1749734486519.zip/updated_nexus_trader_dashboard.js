
// Nexus-Trader upgraded UI logic
import React from 'react';
import { useEffect, useState } from 'react';

export default function NexusTraderDashboard() {
  const [metrics, setMetrics] = useState({accuracy: 0, speed: 0, profit: 0, audit: 0});
  const [lastSignal, setLastSignal] = useState("Initializing...");

  useEffect(() => {
    const interval = setInterval(() => {
      fetch('/api/qnis-metrics')
        .then(res => res.json())
        .then(data => {
          setMetrics(data);
          setLastSignal(data.lastSignal);
        });
    }, 2000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="bg-black text-green-400 p-4 rounded-xl shadow-lg">
      <h1 className="text-xl font-bold">🚀 Nexus-Trader AI Console</h1>
      <p>Last Signal: <span className="text-yellow-300">{lastSignal}</span></p>
      <div className="grid grid-cols-2 gap-4 mt-4">
        <div>Accuracy: {metrics.accuracy}%</div>
        <div>Speed: {metrics.speed}%</div>
        <div>Profit: {metrics.profit}%</div>
        <div>Audit: {metrics.audit}%</div>
      </div>
    </div>
  );
}
