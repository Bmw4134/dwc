
def initialize_unlock_protocol(dashboard):
    if current_user.role in ["admin", "founder"]:
        dashboard.modules["restricted"] = "unlocked"
        dashboard.log("✅ Global unlock confirmed.")
        return True
    return False
