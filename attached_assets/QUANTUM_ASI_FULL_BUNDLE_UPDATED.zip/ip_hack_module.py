# ip_hack_module.py
SAFE_ARTISTS = {
    "DomDolla": "choppress.domdna",
    "Tinashe": "glidehook.airshift",
}

def get_safe_tag(artist):
    return SAFE_ARTISTS.get(artist, "generic.flow")
