# quantum_launcher.py
from quantum_asi_core import LyricBrain

class Puppeteer:
    def __init__(self):
        self.engine = LyricBrain()

    def compose(self, mode="REMI", theme="emotive club", title="Untitled"):
        self.engine.mode = mode
        return self.engine.compose(track_style=theme)
