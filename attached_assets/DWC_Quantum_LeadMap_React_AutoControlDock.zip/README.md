# Quantum Lead Map React App
Instructions to run:
1. Install deps
2. Start dev server
3. Launch Puppeteer if needed
4. Enjoy floating automation HUD