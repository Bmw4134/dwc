// Test runner for CI
