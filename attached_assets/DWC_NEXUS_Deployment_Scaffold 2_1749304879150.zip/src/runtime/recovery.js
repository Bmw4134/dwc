// Runtime recovery & fallback routing
