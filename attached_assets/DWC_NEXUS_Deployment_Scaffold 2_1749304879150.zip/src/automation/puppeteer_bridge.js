// Browser automation bridge
