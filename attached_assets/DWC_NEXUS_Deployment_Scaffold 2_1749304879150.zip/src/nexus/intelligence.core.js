// NEXUS kernel logic
