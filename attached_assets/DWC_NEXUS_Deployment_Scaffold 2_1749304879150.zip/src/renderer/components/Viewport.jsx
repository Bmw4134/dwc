// Visual automation split-view
